# IVIS core tasks package 

Library for tasks in IVIS project

## Install
Change to directory containing this README file and run:

```
python3 setup.py sdist bdist_wheel
```